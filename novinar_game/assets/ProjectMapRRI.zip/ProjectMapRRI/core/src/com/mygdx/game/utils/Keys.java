package com.mygdx.game.utils;

public class Keys {
    public static String MAPBOX = "";
    public static String GEOAPIFY = "";
}
